%LM: K x 2 vector of local maxima of D
% In the case that D is symmetric the half local maxima are used (using diagonal)

function [LM,HashMat,LMIM,TreshLow,Tresh,isSymmetric,Bitmap,nALL] = getLocalMinimaSelf(D,DFilt,SearchWindow,T_L_c1,T_H_c2,toPlot)

D = DFilt+D;

d = mean(mean(abs(diff(D))));
for i=1:size(D,1),
    for j=i+1:size(D,1),
        D(i,j) = D(i,j)+d*(j-i)*0.00000001;
    end
end

isSymmetric = 1;

[Bitmap] = getDBasedonLocalMaximaAndDiagonal(D,DFilt,toPlot);

MMD = max(max(D));
LMIM = imregionalmin(D,8);
LMIM(Bitmap ~= 1) = 0;
LMAX = imregionalmax(D,8);
LMAX(Bitmap ~= 1) = 0;
Dval = sort(D(:));

DvalMIN = sort(D(LMIM));
DvalMAX = sort(D(LMAX));
NMIN = length(DvalMIN);
m1 = mean(DvalMIN);
s1 = var(DvalMIN);
m2 = mean(DvalMAX);
s2 = var(DvalMAX);
b10 = s1/m1;
a10 = m1/b10;

for i=0:round(0.75*NMIN),
    if i == 0,
        m1 = mean(DvalMIN(1:NMIN));
        s1 = var(DvalMIN(1:NMIN));
        ss2 = sum(DvalMIN(1:NMIN).^2);
        ss = sum(DvalMIN(1:NMIN));
    else
        ss2 = ss2 - (DvalMIN(NMIN-i+1)^2);
        ss = ss - DvalMIN(NMIN-i+1);
        m1 = (ss)/(NMIN-i);
        s1 = (ss2/(NMIN-i))-(m1^2);
    end
   
    b1 = s1/m1;
    a1 = m1/b1;
    prop_m2 = 1-gamcdf(m2,a1,b1);
    
    if prop_m2 < 0.1,%0.02????
        break;
    end
    
end
bins = [Dval(1):0.001*(max(Dval)-Dval(1)):2*max(Dval)];


b1 = s1/m1;
a1 = m1/b1;
b2 = s2/m2;
a2 = m2/b2;


norm1 = gampdf(bins,a1,b1);

norm2 = normpdf(bins,m2,sqrt(s2));

pnorm = 1-gamcdf(bins,a1,b1);
pnorm0 = 1-gamcdf(bins,a10,b10);

DProp = [];


c2 = T_H_c2;
c1 = T_L_c1;




pnorm_pos = find(pnorm < c2);
Tresh = bins(pnorm_pos(1))
pnorm_pos2 = find(pnorm < c1);
TreshLow = bins(pnorm_pos2(1))
if TreshLow == 0,
    TreshLow = Tresh;
end


perc = 100*length(find(D < Tresh)) / numel(D);
disp(sprintf('Percetange of pixels less than Tresh:%2.2f',perc));

perc2 = 100*length(find(D < TreshLow)) / numel(D);
disp(sprintf('Percetange of pixels less than Low Tresh:%2.2f',perc2));
D(Bitmap ~= 1) = MMD;
[a, b] = find(LMIM == 1 & D < Tresh);

LM = [];
LM(:,1) = a;
LM(:,2) = b;
LM(:,3) = 1;

disp(sprintf('Number of Local Minima: %d',size(LM,1)));
LMsize1 = size(LM,1);
LM = increaseSampling(LM,D,Tresh,SearchWindow,toPlot);
VAL_LM  = getLMpointsDirection(LM,D);


%compute hash matrix
HashMat = zeros(size(D,1),size(D,2));
for i=1:size(LM,1),
    HashMat(LM(i,1),LM(i,2)) = i;%LM(i,3) == 1 && 
    if LM(i,3) == 1 && D(LM(i,1),LM(i,2)) < TreshLow,%Denotes if the point is candicate for end point of the motif 
        if VAL_LM(i) < 0,
            LM(i,3) = -1;%START
        elseif VAL_LM(i) > 0 ,
            LM(i,3) = 1;%END
        else
            LM(i,3) = 0;
        end
            
    else
        LM(i,3) = 10;
    end
end

nALL = length(find(LM(:,3) ~= 10));
nstart = length(find(LM(:,3) <= 0));
nend = length(find(LM(:,3) >= 0 & LM(:,3) ~= 10));

disp(sprintf('TOTAL_POINTS = %d Start points: %d  End points:%d',nALL,nstart,nend));

if toPlot == 1,
    figure;
    plot(bins, norm1,'r');
    hold on;
    plot(bins, norm2,'b');%h2/length(DvalMAX)
    hold on;
    plot(bins,pnorm0,'g');
    hold on;
    plot(bins,pnorm,'k');
    legend('pMIN','pMAX','1-cdf (init)','1-cdf');
    title('Histogramm LMIN LMAX');
    
    figure;%??????
    imagesc(DProp);
    title('Prop Distance matrix');
    colormap('jet');
    figure;
    imagesc(D);
    title(sprintf('NEW PLOT!!! Local Minima %d (+) - Extra samples %d (o)  Tr = %2.2f',LMsize1,size(LM,1)-LMsize1,Tresh));
    colormap('jet');
    for i=1:size(LM,1),
        if LM(i,3) == -1
            text(LM(i,2),LM(i,1),'+');
            hold on;
        elseif LM(i,3) == 1
            text(LM(i,2),LM(i,1),'o');
            hold on;
        elseif LM(i,3) == 0
            text(LM(i,2),LM(i,1),'x');
            hold on;
        end
    end
    figure;
    imagesc(D);
    for i=1:size(LM,1),
        text(LM(i,2)-5,LM(i,1),'+', 'Color','w');
    end
    figure;
    imagesc(D);
    title(sprintf('Local Minima %d (+) - Extra samples %d (o)  Tr = %2.2f',LMsize1,size(LM,1)-LMsize1,Tresh));
    colormap('jet');
    for i=1:size(LM,1),
        if i <= LMsize1 && D(LM(i,1),LM(i,2)) < TreshLow
            text(LM(i,2)-4,LM(i,1),'+','Color','r');
            hold on;
        elseif i <= LMsize1 
            text(LM(i,2)-4,LM(i,1),'x','Color','g');
            hold on;
        else
            text(LM(i,2)-4,LM(i,1),'o','Color','y');
            hold on;
        end
    end
    colormap('gray');
end



function [NLM] = increaseSampling(LM,D,Tresh,SearchWindow,toPlot)
NLM = LM;
WindowMin = round(SearchWindow/3);

%temp = bwmorph(D < Tresh,'skel',Inf);
temp = D < Tresh;

lines = size(D,1);
cols = size(D,2);
for i=1:size(LM,1),
    x = LM(i,1);
    y = LM(i,2);
    apoX = max(1,x-WindowMin);
    eosX = min(lines,x+WindowMin);
    apoY = max(1,y-WindowMin);
    eosY = min(cols,y+WindowMin);
    %temp(apoX:eosX,apoY:eosY) = 0;
    for i1=apoX:eosX
        for i2=apoY:eosY,
            if (i1-x)^2+(i2-y)^2 <= WindowMin^2
                temp(i1,i2) = 0;
            end
        end
    end
end

DT = bwdist(1-temp);
%DT = temp;
if toPlot > 0,
    figure;
    imagesc(DT);
    title('Distance Tranform');
end
[a,b] = find(DT > 0);
vec = zeros(1,length(a));
for i=1:length(a),
    vec(i) = D(a(i),b(i));
end
disp(sprintf('Candidates for extra points: %d',length(a)));
[~,pos] = sort(vec);
k = size(LM,1);
NLM(k+1:round(k+1+(2*length(a)/SearchWindow)),:) = 0;
for i=1:length(a),
    x = a(pos(i));
    y = b(pos(i));
    
    if DT(x,y) == 0,
        continue;
    end
    k = k+1;
    NLM(k,1) = x;
    NLM(k,2) = y;
    
    apoX = max(1,x-WindowMin);
    eosX = min(lines,x+WindowMin);
    apoY = max(1,y-WindowMin);
    eosY = min(cols,y+WindowMin);
    for i1=apoX:eosX
        for i2=apoY:eosY,
            if (i1-x)^2+(i2-y)^2 <= WindowMin^2
                DT(i1,i2) = 0;
            end
        end
    end
    %DT(apoX:eosX,apoY:eosY) = 0;
end
NLM = NLM(1:k,:);
disp(sprintf('Number of Local minima points after increaseSampling: %d (+%d)',k,k-size(LM,1)));



function [Bitmap] = getDBasedonLocalMaximaAndDiagonal(D,DFilt,toPlot)

Dorig = D;
h = fspecial('average', [7 7]);
D = imfilter(D,h,'symmetric');

LMAX = imregionalmax(D,8);
LMIN = imregionalmin(D,8);
[Gx, Gy] = imgradientxy(Dorig);

h = fspecial('average', [9 9]);

Gx = imfilter(Gx,h,'symmetric');
Gy = imfilter(Gy,h,'symmetric');

%[mag,phase] = imgaborfilt(Dorig,10,45);

[Gmag, ~] = imgradient(Gx, Gy);
Gmag = imfilter(Gmag,h,'symmetric');
Gmag = Gmag/max(max(Gmag));

D = imfilter(Dorig,h,'symmetric');
%SNR = stdfilt(D,ones(9))/sqrt(var(D(:)));
SNR = (stdfilt(D,ones(9))).^2./(stdfilt(Dorig,ones(9))*sqrt(var(D(:))));
%F1 = Gmag/max(max(Gmag));

Bit = SNR > 0.02 | Gmag > 0.1;
se = strel('disk',5);
Bit = imclose(Bit,se);



I = eye(size(D,1),size(D,1));
DT1 = bwdist(I);
DT2 = bwdist(LMAX);
DT3 = bwdist(LMIN);
se = strel('disk',8);
I = imdilate(I,se);
UpTr = 1-tril(ones(size(D,1),size(D,2)),0);
Bitmap = double(UpTr == 1 & I == 0 & Bit == 1);
disp(sprintf('Remove per = %2.2f pixels (Bit)',100*mean(mean(1-Bit))))
TMAX = min(200,round(size(D,1)/3));
TMIN = 6;
for i=1:size(D,1),
    for j=i+1:size(D,2),
        T = j-i;
        if T < TMIN || T > TMAX,
            Bitmap(i,j) = 0;
        elseif DT1(i,j) <= DT2(i,j)-1 || DT1(i,j) <= DT3(i,j)-1,
            Bitmap(i,j) = 0;
        elseif T > (size(D,2)/2)+1
            Bitmap(i,j) = -1;
        end
    end
end

if toPlot == 1,
figure;
imagesc(D.*Bitmap+Bitmap);
hold on;
plot([1 size(D,1)], [1 size(D,1)],'w');
colormap('jet');
end
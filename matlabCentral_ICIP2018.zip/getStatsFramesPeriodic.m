% intersection / GT_common_action
%rec:recall
%pr: precision
%coverage
%overlap
%F1
function [rec,pr,F1,coverage,overlap] = getStatsFramesPeriodic(V,PeriodicFrames,PeriodicLabels,Motif)
DetFrames = zeros(1,length(PeriodicFrames));
for i=1:size(Motif,1),
    apo = Motif(i,1);
    eos = Motif(i,2);
    DetFrames(apo:eos) = 1;
end

T1 = find(PeriodicFrames == 1 & DetFrames == 1);
U1 = find(PeriodicFrames == 1 | DetFrames == 1);
TOMH = length(T1);
ENWSH = length(U1);


overlap = TOMH / max(ENWSH,0.000001);
rec =  TOMH / max(length(find(PeriodicFrames == 1)),0.000001);
coverage = rec;
pr =   TOMH / max(length(find(DetFrames == 1)),0.000001);
F1 = 2*(rec*pr) / max((rec+pr),0.0000000001);



function [rec,pr,F1,coverage,overlap] = getStatsDiagonal_old(V,GT_common_action,Motif)
M = size(Motif,1);%number of motifs
maxP = max(max(V(:,1:2)));
IGT = zeros(maxP,maxP);
DGT = zeros(maxP,maxP);

IR = zeros(maxP,maxP);
DR = zeros(maxP,maxP);

GT_common_action = double(GT_common_action);

for i=1:size(GT_common_action,1),
    GTx1 = GT_common_action(i,1);
    GTx2 = GT_common_action(i,3);
    GTy1 = GT_common_action(i,2);
    GTy2 = GT_common_action(i,4);
    GTx = [GTx1:GTy1];
    GTy = [GTx2:GTy2];
    
    IGT(GTx,GTy) = 1;
    
    le = norm([GTy1-GTx1+1 GTy2-GTx2+1]);
    [xx,yy]=fillline([GTx1 GTx2],[GTy1 GTy2],1+round(le));
    xxIN = round(xx);
    yyIN = round(yy);
    
    for j=1:length(xxIN),
        DGT(xxIN(j),yyIN(j)) = 1;
    end
end

for k=1:M,
    x1 = V(Motif(k,1),1);
    y1 = V(Motif(k,2),1);
    
    x2 = V(Motif(k,1),2);
    y2 = V(Motif(k,2),2);
    
    x = [x1:y1];
    y = [x2:y2];
    IR(x,y) = 1;
    
    le = norm([y1-x1+1 y2-x2+1]);
    [xx,yy]=fillline([x1 x2],[y1 y2],1+round(le));
    xxIN = round(xx);
    yyIN = round(yy);
    
    for i=1:length(xxIN),
        DR(xxIN(i),yyIN(i)) = 1;
    end
end
LR = 0;
LGT = 0;
IN = 0;
for i=1:size(DR,1),
    for j=1:size(DR,2),
        if DR(i,j) == 1,
            LR = LR+1;
            if IGT(i,j) == 1,
                IN = IN+1;
            end
        end
        if DGT(i,j) == 1,
            LGT = LGT+1;
            if IR(i,j) == 1,
                IN = IN+1;
            end
        end
    end
end

overlap = 0.5*IN / (LR+LGT-0.5*IN);
coverage = 0.5*IN / LGT;

rec =  0.5*IN / LGT;
pr =   0.5*IN / LR;
F1 = 2*(rec*pr) / max((rec+pr),0.0000000001);


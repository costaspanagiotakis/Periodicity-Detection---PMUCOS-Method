This code is a simple  implementation of OF Unsupervised Detection of Periodic
Segments in Videos method (P-MUCOS) PROPOSED IN [1] 

Given an self-distance matrix (D) of an action sequence, our method
discovers all periodic parts of the sequence.

You can find more details in [1]  

Files: 
   runMotifDetector: implemetation of the method
  
[1]C. Panagiotakis, G. Karvounas, and A. Argyros, Unsupervised Detection of Periodic Segments 
in Videos, IEEE International Conference on Image Processing, 2018.

Visit the folowing webpages to download datasets from: 
http://www.ics.forth.gr/cvrl/pd
https://sites.google.com/site/costaspanagiotakis/research/pd


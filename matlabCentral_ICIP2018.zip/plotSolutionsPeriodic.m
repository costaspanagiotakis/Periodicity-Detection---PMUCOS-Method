function [hfig] = plotSolutionsPeriodic(GT_common_action,PeriodicLabels,segments_ab,D,V,Path,BestSegment,k,hfig,stats)


temp = D;
if hfig > 0,
    
else
    hfig = figure;
    imagesc(temp);
    colormap('jet');
end
for i=1:k,
    hold on;
    spath = Path{i};
    x = V(spath,2);
    y = V(spath,1);
    if i == BestSegment,
        plot(x,y,'w','LineWidth',2);
    else
        %plot(x,y,'w-.','LineWidth',2);
        plot(x,y,'w','LineWidth',2);
    end
    hold on;
    % text(x(1),y(1),sprintf('%d',spath(1)));
    % hold on;
    % text(x(length(spath)),y(length(spath)),sprintf('%d',spath(length(spath))));
end
for i=1:size(segments_ab,1),
    if PeriodicLabels(i) == 1,
        x1 = segments_ab(i,1);
        y1 = x1;
        x2 = segments_ab(i,2);
        y2 = x2;
        plot([y1 y2],[x1 x2],'w:o','LineWidth',1.5);
    end
end

for i=1:size(GT_common_action,1),
    x1 = GT_common_action(i,1);
    y1 = GT_common_action(i,3);
    x2 = GT_common_action(i,2);
    y2 = GT_common_action(i,4);
    plot([y1 y2],[x1 x2],'k:o','LineWidth',1.5);
end


%title(sprintf('TLow = %2.2f THigh = %2.2f  Rec = %2.2f Prec = %2.2f F1 = %2.2f Cov = %2.2f Overlap = %2.2f',Tr(1),Tr(2),stats(1),stats(2),stats(3),stats(4),stats(5)));
title(sprintf('Rec = %2.1f%s Prec = %2.1f%s F_1 = %2.1f%s Overlap = %2.1f%s',100*stats(1),'%',100*stats(2),'%',100*stats(3),'%',100*stats(5),'%'));
colorbar;

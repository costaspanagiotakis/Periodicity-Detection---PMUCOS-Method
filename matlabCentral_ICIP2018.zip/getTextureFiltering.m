% Perform FAST texture filtering on pixels where Bitmap = 1
function [DFilt] = getTextureFiltering(D,Bitmap,toPlot)
%h = fspecial('average', [5 5]);
%D = imfilter(D,h,'symmetric');
%[DFilt] = getTextureFiltering_normal(D,Bitmap,toPlot);
%return;
N = size(D,1);
DFilt = zeros(N,N);
%DFilt2 = DFilt;
TMAX = min(200,round(N/3));
TMIN = 6;

for T=TMIN:TMAX,
    H{T} = createmyFilter(T,0);
end

%createmyFilter(20,1);
for T=TMIN:TMAX,
    h = H{T};
    habs = abs(h);
    N1 = size(h,1);
    eos = (N1-1)/2;
    apo = -eos;

    for i=1:N-T,
        j = i+T;
        if i == 1,
            s = 0;
            dsum = 0;
            for x=apo:eos,
                for y=apo:eos,
                    u = x+i; %mirroring
                    v = y+j;
                    if u <= 0 || v  <= 0 || u > N || v > N,
                        continue;
                    end
                    dsum = dsum+habs(x+eos+1,y+eos+1);
                    s = s+D(u,v)*h(x+eos+1,y+eos+1);
                end
            end
        else
            dsumrem = 0;
            srem = 0;
            x = apo;
            for y=apo:eos,
                u = x+i-1; %mirroring
                v = y+j-1;
                if u <= 0 || v  <= 0 || u > N || v > N,
                    continue;
                end
                srem = srem+D(u,v)*h(x+eos+1,y+eos+1);
                dsumrem = dsumrem+habs(x+eos+1,y+eos+1);
            end
            y = apo;
            for x=apo+1:eos,
                u = x+i-1; %mirroring
                v = y+j-1;
                if u <= 0 || v  <= 0 || u > N || v > N,
                    continue;
                end
                srem = srem+D(u,v)*h(x+eos+1,y+eos+1);
                dsumrem = dsumrem+habs(x+eos+1,y+eos+1);
            end
            sadd = 0;
            dsumadd = 0;
            x = eos;
            for y=apo:eos,
                u = x+i; %mirroring
                v = y+j;
                if u <= 0 || v  <= 0 || u > N || v > N,
                    continue;
                end
                sadd = sadd+D(u,v)*h(x+eos+1,y+eos+1);
                dsumadd = dsumadd+habs(x+eos+1,y+eos+1);
            end
            
            y = eos;
            for x=apo:eos-1,
                u = x+i; %mirroring
                v = y+j;
                if u <= 0 || v  <= 0 || u > N || v > N,
                    continue;
                end
                sadd = sadd+D(u,v)*h(x+eos+1,y+eos+1);
                dsumadd = dsumadd+habs(x+eos+1,y+eos+1);
            end
            s = sprev-srem+sadd;
            dsum = dsumprev-dsumrem+dsumadd;
        end
        sprev = s;
        dsumprev = dsum;
        if Bitmap(i,j) == 1
           % dmean = dsum/((eos-apo+1)^2);
            DFilt(i,j) = s/dsum;
           % DFilt2(i,j) = s;
        end
    end
end

DFt = DFilt;

for i=1:N,
    for j=i+1:N,
        T = j-i;
        if T >= TMIN && T <= TMAX,
            me = round((i+j)/2);
            DFt(i,j) = DFilt(i,j) - DFilt(me-round(T/4),me+round(T/4));
          %  if me-T > 0 && me+T <= size(D,1)
          %      DFt(i,j) = DFt(i,j) -  0.5*DFilt(me-T,me+T) - 0.5*DFilt(me-round(T/4),me+round(T/4));
          %  else
          %      DFt(i,j) = DFilt(i,j) - DFilt(me-round(T/4),me+round(T/4));
          %  end
        end
    end
end
DFilt = DFt;
DFilt = -DFilt+max(DFilt(:));


if toPlot == 1,
    figure;
    imagesc(D);
    figure;
    imagesc(DFilt);
    title('Filtering');
   % figure;
   % imagesc(DFilt2);
   % title('Filtering');
    sum(sum(DFilt))
   % sum(sum(DFilt2))
   createmyFilter(80,toPlot);
end


% Perform texture filtering on pixels where Bitmap = 1
function [DFilt] = getTextureFiltering_normal(D,Bitmap,toPlot)
N = size(D,1);
DFilt = zeros(N,N);

TMAX = min(200,round(N/3));
TMIN = 6;

for T=TMIN:TMAX,
    H{T} = createmyFilter(T,0);
end

%createmyFilter(20,1);
for i=1:N,
    for j=i+1:N,
        T = j-i;
        if Bitmap(i,j) == 1 && T <= TMAX && T >= TMIN,
            h = H{T};
            N1 = size(h,1);
            eos = (N1-1)/2;
            apo = -eos;
            s = 0;
            for x=apo:eos,
                for y=apo:eos,
                    u = x+i; %mirroring
                    v = y+j;
                    if u <= 0 || v  <= 0 || u > N || v > N,
                        continue;
                    end
%                     if u <= 0,
%                         u = -u+1;
%                     elseif u > N,
%                         u = N-(u-N);
%                     end
%                     if v <= 0,
%                         v = -v+1;
%                     elseif v > N,
%                         v = N-(v-N);
%                     end
                    s = s+D(u,v)*h(x+eos+1,y+eos+1);
                end
            end
            DFilt(i,j) = s;   
        end
    end
end

if toPlot == 1,
    figure;
    imagesc(D);
    figure;
    imagesc(DFilt);
    title('Filtering');
    createmyFilter(80,toPlot);
end

function h = createmyFilter(T,toPlot)
N = T;
if rem(N,2) == 0,
    N = N+1;
end
% if N < 30,
%     N = 2*T+1;
% end

h = zeros(N,N);

for i=1:N,
    for j=i:N,
        d = j-i;
       % cm = sqrt((i-N/2)^2+(j-N/2)^2);
       % d1 = sqrt(cm^2-d^2);
        h(i,j) = -(cos(2*pi*d/T))*(N-d);%*(exp(-(2*d1/N)));
        h(j,i) = h(i,j);
    end
end
h = h/abs(sum(sum(abs(h))));
if toPlot == 1,
    figure;
    imagesc(h);
    mean(h(:))
end
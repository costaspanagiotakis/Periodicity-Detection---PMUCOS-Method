% 
% This code is a simple  implementation of OF Unsupervised Detection of Periodic
% Segments in Videos method (P-MUCOS) PROPOSED IN [1] 
% 
% Given an self-distance matrix (D) of an action sequence, our method
% discovers all periodic parts of the sequence.
% 
% You can find more details in [1]  
% 
% Files: 
%    runMotifDetector: implemetation of the method
%   
% [1]C. Panagiotakis, G. Karvounas, and A. Argyros, Unsupervised Detection of Periodic Segments 
% in Videos, IEEE International Conference on Image Processing, 2018.
% 
% Visit the folowing webpages to download datasets from: 
% http://www.ics.forth.gr/cvrl/pd
% https://sites.google.com/site/costaspanagiotakis/research/pd
% 

close all;
clear all;


REMOVE_EDGES = 1; %RUN remove edges (descrease computation cost)

DataDir = 'Dataset//';
ResultsDir = 'Res//'; %Results folder
fname = 'data1';% filename of distance matrix (mat file)
toPlot =0;
%toPlot = 0: it plots only the figure of detections with ground truth projected on matrix diagonal
%toPlot = 1: it also plots several intermediate results 

tic
load(sprintf('%s%s.mat',DataDir,fname)); %load distance matrix (mat file) 

D = dist_mat;

load(sprintf('%sgt_common_%s.mat',DataDir,fname)); %load ground truth mat file 

try
    GT_common_action = common_action;
catch
    GT_common_action = common_actions+1;
end

fname
WindowMin = 30;%half of minimum size of motif  (parameter of MUCOS)
SearchWindow = 30;%search window to connect points (parameter of MUCOS)


RUNSMOOTH = 1;
T_L_c1 = 0.5;  %T_L parameter of MUCOS 
T_H_c2 = 0.1;  %T_H parameter of MUCOS 
WindowMinS = 2*SearchWindow;%minimum size of motif  (parameter of MUCOS)


if min(min(D)) == 0,
    gmin = min(min(D(D > 0)));
    disp('GMIN Correction:');
    disp(gmin/100);
    D = max(D,gmin/100);
end

[DFilt] = getTextureFiltering(D,ones(size(D,1),size(D,2)),toPlot);
Dorig = D;
[LM,HashMat,LMIM,TreshLow,Tresh,isSymmetric,Bitmap,nALL] = getLocalMinimaSelf(D,DFilt,SearchWindow,T_L_c1,T_H_c2,toPlot);
if RUNSMOOTH == 1, %smoothing of Distance Matrix (Optional step)
    for i=1:8,
        if nALL < 2*size(D,1),
            break;
        end
        Dprev = D;
        D = imgaussfilt(D,0.5+(i/8)^2);
        [LM,HashMat,LMIM,TreshLow,Tresh,isSymmetric,Bitmap,nALL] = getLocalMinimaSelf(D,DFilt,SearchWindow,T_L_c1,T_H_c2,toPlot);
        if nALL < 30,
            D = Dprev;
            [LM,HashMat,LMIM,TreshLow,Tresh,isSymmetric,Bitmap,nALL] = getLocalMinimaSelf(D,DFilt,SearchWindow,T_L_c1,T_H_c2,toPlot);
            break;
        end
    end
end
D = Dorig;
%Greate Graph 
[G,Gvot,LM,~,~] = getGraphSelf(REMOVE_EDGES,D+DFilt,Bitmap,Tresh,LM,HashMat,SearchWindow,toPlot);
[S, C] = graphconncomp(sparse(G),'Directed','true','Weak','true'); %weakly connected components
%run MUCOS
[Segments,BestSegment,stats,hfig] = getMultipleSegmentsSelfPeriodic(D,LM,G,C,S,WindowMinS,GT_common_action,PeriodicFrames,PeriodicLabels,segments_ab,1);

j = 1;
timeElapsed(j) = toc

%saving stats and figures
saveas(hfig,sprintf('%smotifs_%s.jpg',ResultsDir,fname));
Overlap = stats(5);
fname = sprintf('%sStats_%2.2f.mat',ResultsDir,100*Overlap);
save(fname,'stats','Segments','timeElapsed','T_L_c1','T_H_c2','WindowMinS');





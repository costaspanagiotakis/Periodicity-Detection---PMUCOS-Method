% computes the graph G (sparse matrix)
% D: Distance Matrix N x N
% B: Binary image N x N
% HashMat: Hash Matrix N x N
% V: Vertices n x 2
% window: size of window
% Gvot: voting graph [-length edge, length edge]
function [G,Gvot,V,G_I,G_J,G_S] = getGraphSelf(REMOVE_EDGES,D,Bitmap,Tresh_2,V,HashMat,window,toPlot)
B = zeros(size(D,1),size(D,2));
B(D > Tresh_2 | Bitmap ~= 1) = 1;

if toPlot == 1,
    temp = D;
    temp(B == 0) = 0;
    cmap = colormap('jet');
    cmap(1,:) = [1 1 1];
    figure;
    imagesc(temp);
    colormap(cmap);
    title('Dist after second threshold');
end


n = size(V,1);
G_I = zeros(1,round(window*n));
G_J = zeros(1,round(window*n));
G_S = zeros(1,round(window*n));

Gvot = [];
N = size(D,1);
M = size(D,2);
k = 0;
for i=1:n,
    x = V(i,1);
    y = V(i,2);
    for i1=1:window,
        for i2=1:window,
            x1 = x+i1;
            y1 = y+i2;
       
            if x1 <= N && y1 <= M && HashMat(x1,y1) > 0,
                
              
                id = HashMat(x1,y1);
                le = max([i1 i2]);
                [xx,yy]=fillline([x y],[x1 y1],1+round(le));

%                 
                xxIN = round(xx);
                yyIN = round(yy);
                vec = B(sub2ind(size(B),xxIN,yyIN));
                if max(vec) > 0
                    continue;
                end
                vec = D(sub2ind(size(D),xxIN,yyIN));

                a = max(i1,i2)/max(0.00001,min(i1,i2));
      
                
                w = sum(vec);
    
                if a > 5,%MAX_DISTORTION
                    continue;
                end
             
                k = k+1;
                G_I(k) = i;
                G_J(k) = id;
                G_S(k) = w*((2*a-1)/a);%*(1+exp(-wF/sv));%*(1+(w/w2));
               
            end
        end
    end
end
G_I = G_I(1:k);
G_J = G_J(1:k);
G_S = G_S(1:k);
G = sparse(G_I,G_J,G_S);
G(size(V,1),size(V,1)) = 0;

disp(sprintf('Number of Egdes: %d',k));
if REMOVE_EDGES == 1,
   
    [G,V] = removeEdgesFast(G_I,G_J,G_S,V);
    [G_I,G_J,G_S] = find(G);
end

if toPlot == 1,
    edgeMap = 0*D;
    for i=1:length(G_I),
        xa = V(G_I(i),1);
        ya = V(G_I(i),2);
        xb = V(G_J(i),1);
        yb = V(G_J(i),2);
        edgeMap = insertShape(edgeMap, 'Line', [ya xa yb xb], 'LineWidth', 1,'Color',[1 0 0],'SmoothEdges',false);
    end
    edgeMap = reshape(edgeMap(:,:,1),N,M);
    temp = D;
    cmap = colormap('jet');
    cmap(1,:) = [0 1 0];
    disp('Edge map size (pixels)');
    disp(length(find(edgeMap == 1)))
    temp(edgeMap == 1) = -max(max(D))/256;
      
    figure;
    imagesc(temp);
    title(sprintf('edgeMap Tr = %2.2f',Tresh_2));
    colormap(cmap);
    for i=1:length(G_I),
        xa = V(G_I(i),1);
        ya = V(G_I(i),2);
        text(ya-4,xa,'+','Color','r');
        xa = V(G_J(i),1);
        ya = V(G_J(i),2);
        text(ya-4,xa,'+','Color','r');
    end
    cmap = gray(256);
    cmap(1,:) = [0 0 1];
    colormap(cmap); 

end






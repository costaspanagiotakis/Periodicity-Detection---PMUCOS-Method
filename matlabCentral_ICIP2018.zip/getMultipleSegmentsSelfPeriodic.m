%Computes the motifs (Segments)
%D: distance matrix
%V:local minima (nodes)
%G:graph of local minima
%C:Connected componets
%minWindow:Minimum size of a motif

function [Segments,BestSegment,stats,hfig] = getMultipleSegmentsSelfPeriodic(D,V,G,C,S,minWindow,GT_common_action,PeriodicFrames,PeriodicLabels,segments_ab,toPlot)
stats = [0 0 0 0 0];
TRESH = 0;
WEIGHT = 1;
hfig = [];
Path{1} = 1;
hfig1 = 0;
h = zeros(1,S);%measures the number of nodes (points) of each connected component
for i=1:length(C),
    h(C(i)) = h(C(i))+1;
end
Segments = zeros(length(h),9);
CostMatrix = -1000000000000000*ones(size(V,1),size(V,1));%Cost matrix of motifs
DistM = zeros(size(V,1),size(V,1));
for i=1:length(h),
    if h(i) > 1,
        pos = find(C == i);
        [CostMatrix,DistM] = getBestPathJonshon(D,CostMatrix,DistM,V,G,pos,minWindow);
     end
end
sizeOrig1 = [];
sizeOrig2 = [];
k = 0;
bestVal = 0;
bestLE = 0;
BestObjective = 0;
Aprev = 0;


[CostMatrix,DistM] = updateCostMatrixPeriodicConstraint(CostMatrix,DistM,V);

while 1,
    val = max(max(CostMatrix));
    
    if val <= 0,
        break;
    end

    [s,t] = find(CostMatrix == val);
    s = s(1);
    t = t(1);
    CostMatrix(s,t) = 0;
  
    
    
    x(1) = V(s,1);
    x(2) = V(t,1);
    
    y(1) = V(s,2);
    y(2) = V(t,2);
    
    x(1) = min(x(1),y(1));
    y(1) = x(1);
    x(2) = max(x(2),y(2));
    y(2) = x(2);
    

    size1 = V(t,1)-V(s,1)+1;
    size2 = V(t,2)-V(s,2)+1;
    
    le = norm([size1 size2]);
    A =   Aprev+size1*size2+WEIGHT*sum(sizeOrig1)*size2+WEIGHT*sum(sizeOrig2)*size1;
    cval = A^1.00 / (DistM(s,t)+bestVal);
    if cval > BestObjective,
        k = k+1;
        bestVal = bestVal+DistM(s,t);
        bestLE = bestLE+A;
        sizeOrig1 = [sizeOrig1 size1];
        sizeOrig2 = [sizeOrig2 size2];
        Aprev = A;
        BestObjective = cval;
        Segments(k,1:9) = [x(1) x(2) 0 bestVal le size1 size2 cval BestObjective];
        [~, spath] = graphshortestpath(G,s,t);
        Path{k} = spath;
        CostMatrix = updateCostMatrixRect(CostMatrix,WEIGHT,A,bestVal,DistM,sizeOrig1,sizeOrig2,V,s,t);
    else
        break;
    end
end

Segments = Segments(1:k,1:9);

BestSegment = 1;
if size(Segments,1) == 1 && bestVal <= 0,
    Segments = [];
end


disp(sprintf('number of motifs=%d',k));

if length(PeriodicFrames) > 0,
    if numel(Segments) > 0,
        [rec,pr,F1,coverage,overlap]  = getStatsFramesPeriodic(V,PeriodicFrames,PeriodicLabels,Segments);
        if sqrt(overlap) >= TRESH,
            stats= [rec,pr,F1,coverage,overlap,k];
        else
            stats= [rec,pr,F1,coverage,0,k];
        end
    else
        stats= [0,0,0,0,0,0];
    end
end

if sum(PeriodicFrames) == 0 && numel(Segments) == 0,
    stats= [1,1,1,1,1,1];
end

if toPlot == 1,
   [hfig] = plotSolutionsPeriodic(GT_common_action,PeriodicLabels,segments_ab,D,V,Path,BestSegment,max(k,1),hfig1,stats);
end



function [CostMatrix] = updateCostMatrixRect(CostMatrix,WEIGHT,A,bestVal,DistM,sizeOrig1,sizeOrig2,V,s,t)
x(1) = V(s,1);
y(1) = V(s,2);
x(2) = V(t,1);
y(2) = V(t,2);


for i=1:size(CostMatrix,1),
    for j=1:size(CostMatrix,2),
        if CostMatrix(i,j) > 0,
            in = 0;
            x_(1) = V(i,1);
            y_(1) = V(i,2);
            x_(2) = V(j,1);
            y_(2) = V(j,2);
            
            if lineSegmentIntersect([x(1) y(1) x(2) y(2)],[x_(1) y_(1) x_(2) y_(2)]) == 1,
                in = 1;
            end
            for k1=1:2,
                for k2=1:2,
                    x0 = x_(k1);
                    y0 = y_(k2);
                    if (x0 >= x(1) && x0 <= x(2)) || (y0 >= y(1) && y0 <= y(2))
                        in = 1;
                        break;
                    end
                end
            end
            for k1=1:2,
                for k2=1:2,
                    x0 = x(k1);
                    y0 = y(k2);
                    if (x0 >= x_(1) && x0 <= x_(2)) || (y0 >= y_(1) && y0 <= y_(2))
                        in = 1;
                        break;
                    end
                end
            end
            if in == 1,
                CostMatrix(i,j) = -3;
            else
                size1 = V(j,1)-V(i,1)+1;
                size2 = V(j,2)-V(i,2)+1;
                D = sum(sizeOrig1)*sum(sizeOrig2)+size1*size2+WEIGHT*sum(sizeOrig1)*size2+WEIGHT*sum(sizeOrig2)*size1;
                %CostMatrix(i,j) = (bestVal*D-A*DistM(i,j)) / ((bestVal+DistM(i,j))*bestVal);
                CostMatrix(i,j) = D / (bestVal+DistM(i,j));
            end
        end
    end
end





%Using of graphallshortestpaths(G)
%Johnson's algorithm O(N^2) cost, where N is the number of LM
function [CostMatrix,DistM] = getBestPathJonshon(D,CostMatrix,DistM,V,G,pos,minWindow)
N = length(pos);
%alfa = 1.1;

DG = zeros(N,N);
for i=1:N,
    s = pos(i);
    for j=1:N,
        d = G(s,pos(j));
        if d > 0,
            DG(i,j) = d;
        end
    end    
end
DG = sparse(DG);

dist = graphallshortestpaths(DG);


for i=1:length(pos),
    s = pos(i);
    x1 = V(s,1);
    y1 = V(s,2);
   if V(s,3) == 10,
       continue;
   end

    for j=1:length(pos),
        t = pos(j);
       if V(t,3) == 10,
           continue;
       end

        x2 = V(t,1);
        y2 = V(t,2);
        if i == j || dist(i,j) == 0 || isinf(dist(i,j)) == 1,
            continue;
        end
        if x2-x1 < 0 || y2-y1 < 0,
            continue;
        end
        
        x(1) = V(s,1);
        x(2) = V(t,1);
        
        y(1) = V(s,2);
        y(2) = V(t,2);
        
        x(1) = min(x(1),y(1));
        y(1) = x(1);
        x(2) = max(x(2),y(2));
        y(2) = x(2);
        
        
        size1 = V(t,1)-V(s,1)+1;
        size2 = V(t,2)-V(s,2)+1;
        
        if y2-x1 < minWindow || x2-x1 < 0.75*minWindow || y2-y1 < 0.75*minWindow,
            continue;
        end
        
        
        %le = sqrt(size1*size2);
        %le = norm([size1 size2]);
        T1 = y1-x1; 
        T2 = y2-x2;
        a = max(size1,size2)/min(size1,size2);
        if a > 2,
            continue;
        end
       % if y1+T1 <= size(D,2) && x2-T2 > 0 && y1-(T1/2) > 0 
       %    
       % else
       %     continue;
       % end
        
        A = size1*size2;
        CostMatrix(s,t) = A^1.00/(dist(i,j));
        DistM(s,t) = dist(i,j);

        
        %CostMatrix(s,t) = le^1.5/(dist(i,j));
    end    
end




%updates the CostMatrix - taking into account that only the periodic
%segments can be inluded
%The rest segments get negative value

function [CostMatrix,distM] = updateCostMatrixPeriodicConstraint(CostMatrix,distM,V)


for i=1:size(CostMatrix,1),
    for j=1:size(CostMatrix,2),
        if CostMatrix(i,j) > 0,
            x(1) = V(i,1);
            y(1) = V(i,2);
            x(2) = V(j,1);
            y(2) = V(j,2);

            e = -1;
            if y(1) <= x(2),
                e = (x(2)-y(1)+1) / min(x(2)-x(1)+1,y(2)-y(1)+1);
            end
            if e < 0 
                CostMatrix(i,j) = -2;
            else
              
            end
        end
    end
end

